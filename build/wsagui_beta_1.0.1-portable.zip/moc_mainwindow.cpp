/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.2.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../wsa-gui/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.2.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    const uint offsetsAndSize[40];
    char stringdata0[375];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs), len 
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 10), // "MainWindow"
QT_MOC_LITERAL(11, 21), // "on_buttonBox_rejected"
QT_MOC_LITERAL(33, 0), // ""
QT_MOC_LITERAL(34, 17), // "on_ubuntu_clicked"
QT_MOC_LITERAL(52, 7), // "checked"
QT_MOC_LITERAL(60, 19), // "on_opensuse_clicked"
QT_MOC_LITERAL(80, 16), // "on_nowsa_clicked"
QT_MOC_LITERAL(97, 14), // "on_vmp_clicked"
QT_MOC_LITERAL(112, 15), // "on_nops_clicked"
QT_MOC_LITERAL(128, 21), // "on_buttonBox_accepted"
QT_MOC_LITERAL(150, 22), // "on_downloadwsa_clicked"
QT_MOC_LITERAL(173, 24), // "on_downloadgapps_clicked"
QT_MOC_LITERAL(198, 15), // "on_nops_pressed"
QT_MOC_LITERAL(214, 19), // "on_mygithub_pressed"
QT_MOC_LITERAL(234, 16), // "on_mswsl_pressed"
QT_MOC_LITERAL(251, 19), // "on_msubuntu_pressed"
QT_MOC_LITERAL(271, 23), // "on_msopensusetw_pressed"
QT_MOC_LITERAL(295, 26), // "on_wsadownloadpage_pressed"
QT_MOC_LITERAL(322, 28), // "on_gappsdownloadpage_pressed"
QT_MOC_LITERAL(351, 23) // "on_msdownloadpw_pressed"

    },
    "MainWindow\0on_buttonBox_rejected\0\0"
    "on_ubuntu_clicked\0checked\0on_opensuse_clicked\0"
    "on_nowsa_clicked\0on_vmp_clicked\0"
    "on_nops_clicked\0on_buttonBox_accepted\0"
    "on_downloadwsa_clicked\0on_downloadgapps_clicked\0"
    "on_nops_pressed\0on_mygithub_pressed\0"
    "on_mswsl_pressed\0on_msubuntu_pressed\0"
    "on_msopensusetw_pressed\0"
    "on_wsadownloadpage_pressed\0"
    "on_gappsdownloadpage_pressed\0"
    "on_msdownloadpw_pressed"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      17,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,  116,    2, 0x08,    1 /* Private */,
       3,    1,  117,    2, 0x08,    2 /* Private */,
       5,    1,  120,    2, 0x08,    4 /* Private */,
       6,    1,  123,    2, 0x08,    6 /* Private */,
       7,    1,  126,    2, 0x08,    8 /* Private */,
       8,    1,  129,    2, 0x08,   10 /* Private */,
       9,    0,  132,    2, 0x08,   12 /* Private */,
      10,    1,  133,    2, 0x08,   13 /* Private */,
      11,    1,  136,    2, 0x08,   15 /* Private */,
      12,    0,  139,    2, 0x08,   17 /* Private */,
      13,    0,  140,    2, 0x08,   18 /* Private */,
      14,    0,  141,    2, 0x08,   19 /* Private */,
      15,    0,  142,    2, 0x08,   20 /* Private */,
      16,    0,  143,    2, 0x08,   21 /* Private */,
      17,    0,  144,    2, 0x08,   22 /* Private */,
      18,    0,  145,    2, 0x08,   23 /* Private */,
      19,    0,  146,    2, 0x08,   24 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    4,
    QMetaType::Void, QMetaType::Bool,    4,
    QMetaType::Void, QMetaType::Bool,    4,
    QMetaType::Void, QMetaType::Bool,    4,
    QMetaType::Void, QMetaType::Bool,    4,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    4,
    QMetaType::Void, QMetaType::Bool,    4,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->on_buttonBox_rejected(); break;
        case 1: _t->on_ubuntu_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 2: _t->on_opensuse_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 3: _t->on_nowsa_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 4: _t->on_vmp_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 5: _t->on_nops_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 6: _t->on_buttonBox_accepted(); break;
        case 7: _t->on_downloadwsa_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 8: _t->on_downloadgapps_clicked((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 9: _t->on_nops_pressed(); break;
        case 10: _t->on_mygithub_pressed(); break;
        case 11: _t->on_mswsl_pressed(); break;
        case 12: _t->on_msubuntu_pressed(); break;
        case 13: _t->on_msopensusetw_pressed(); break;
        case 14: _t->on_wsadownloadpage_pressed(); break;
        case 15: _t->on_gappsdownloadpage_pressed(); break;
        case 16: _t->on_msdownloadpw_pressed(); break;
        default: ;
        }
    }
}

const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_MainWindow.offsetsAndSize,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
qt_incomplete_metaTypeArray<qt_meta_stringdata_MainWindow_t
, QtPrivate::TypeAndForceComplete<MainWindow, std::true_type>
, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<bool, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<bool, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<bool, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<bool, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<bool, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<bool, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<bool, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>


>,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 17)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 17;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 17)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 17;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
